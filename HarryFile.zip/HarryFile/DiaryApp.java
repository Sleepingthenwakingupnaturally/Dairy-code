import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class DiaryApp {

    static final String DIARY_FILE = "dairy.txt";
    static Scanner input = new Scanner(System.in);

    public static void main(String[] args) {
        int choice = 0;

        while (choice != 4) {
            System.out.println("Simple Diary Application Menu:");
            System.out.println("1. Add Diary");
            System.out.println("2. Show All Diary");
            System.out.println("3. Show Diary");
            System.out.println("4. Exit");
            System.out.print("Type Here: ");

            if (input.hasNextInt()) {
                choice = input.nextInt();
                input.nextLine();

                switch (choice) {
                    case 1:
                        addDiary();
                        break;
                    case 2:
                        ShowAllDiary();
                        break;
                    case 3:
                        ShowDiary();
                        break;
                    case 4:
                        System.out.println("Terminated");
                        break;
                    default:
                        System.out.println("Invalid choice.");
                }
                System.out.println();
            } else {
                System.out.println("Invalid input. Please enter a number.");
                input.nextLine();
            }
        }

        input.close();
    }

    static void addDiary() {
        System.out.println("\nAdding New Diary Entry:");
        System.out.print("Enter ID: ");
        String id = input.nextLine();
        System.out.print("Enter Date (YYYY/MM/DD): ");
        String date = input.nextLine();
        System.out.println("Enter Diary Content (type '.' on a new line to finish):");
        StringBuilder content = new StringBuilder();
        String line;
        while (true) {
            line = input.nextLine();
            if (line.equals(".")) {
                break;
            }
            content.append(line).append("\n");
        }

        try (PrintWriter fileWriter = new PrintWriter(new FileWriter(DIARY_FILE, true))) {
            fileWriter.println(id);
            fileWriter.println(date);
            fileWriter.println(content.toString().trim());
            System.out.println("Diary entry saved successfully!");
        } catch (IOException error) {
            System.err.println("Error saving to file: " + error.getMessage());
        }
    }

    static void ShowAllDiary() {
        System.out.println("\n--- All Diary Entries ---");
        try (BufferedReader fileReader = new BufferedReader(new FileReader(DIARY_FILE))) {
            String id;
            int entryNumber = 1;
            while ((id = fileReader.readLine()) != null) {
                String date = fileReader.readLine();
                StringBuilder contentBuilder = new StringBuilder();
                String line;
                while ((line = fileReader.readLine()) != null && !line.isEmpty()) {
                    contentBuilder.append(line).append("\n");
                }
                String content = contentBuilder.toString().trim();

                System.out.println("Entry #" + entryNumber);
                System.out.println("ID: " + id);
                System.out.println("Date: " + date);
                System.out.println("Content:\n" + content);
                System.out.println("-----------------------");
                entryNumber++;
            }
            if (entryNumber == 1) {
                System.out.println("No diary entries found yet.");
            }
        } catch (IOException error) {
            System.err.println("Error reading from file: " + error.getMessage());
        }
    }

    static void ShowDiary() {
        System.out.print("\nEnter the ID of the diary entry you want to view: ");
        String searchId = input.nextLine();
        boolean found = false;
        try (BufferedReader fileReader = new BufferedReader(new FileReader(DIARY_FILE))) {
            String id;
            while ((id = fileReader.readLine()) != null) {
                String date = fileReader.readLine();
                StringBuilder contentBuilder = new StringBuilder();
                String line;
                while ((line = fileReader.readLine()) != null && !line.isEmpty()) {
                    contentBuilder.append(line).append("\n");
                }
                String content = contentBuilder.toString().trim();

                if (id.equals(searchId)) {
                    System.out.println("\n--- Diary Entry with ID: " + searchId + " ---");
                    System.out.println("ID: " + id);
                    System.out.println("Date: " + date);
                    System.out.println("Content:\n" + content);
                    System.out.println("------------------------------------------");
                    found = true;
                    break;
                }
            }
            if (!found) {
                System.out.println("Diary entry with ID '" + searchId + "' not found.");
            }
        } catch (IOException error) {
            System.err.println("Error reading from file: " + error.getMessage());
        }
    }
}
